# Guía de dependencias entre entidades

## 1. Introducción

Este documento describe las dependencias y relaciones entre las entidades del sistema de gestión de laboratorios de Ingeniería Mecatrónica para el periodo 2025B. El objetivo es dejar claro qué entidad depende de cuál, en qué orden se deberían crear o eliminar los datos y qué reglas básicas se aplican a las reservas de los laboratorios.

El modelo está intencionalmente reducido a dos laboratorios y dos asignaturas, con la idea de mantener un diseño simple pero coherente con la programación orientada a objetos en Python.

---

## 2. Concepto de dependencia

En este contexto, una dependencia significa que una entidad hija necesita una referencia válida a otra entidad padre para que su existencia tenga sentido dentro del sistema.

Algunos ejemplos sencillos:

- Un grupo no puede existir sin una asignatura asociada.
- Un estudiante no puede existir sin un grupo.
- Una reserva no puede existir si no tiene laboratorio, grupo y docente válidos.

### Tipos de relaciones

- 1:1 – Uno a uno  
- 1:* – Uno a muchos (un padre puede tener varios hijos)  
- N:1 – Muchos a uno (muchos hijos apuntan al mismo padre)  

---

## 3. Árbol de dependencias

El modelo se puede ver como dos ramas que se conectan en la entidad Reserva.

### 3.1. Rama académica (Asignatura, Grupo, Estudiante)

```text
ASIGNATURA [Nivel 0 - Independiente]
│
├─ atributos: id, nombre, semestre
├─ ejemplos:
│  ├─ ID=1, "Diseño mecatrónico", semestre 7
│  └─ ID=2, "Electrónica", semestre 6
│
└──> GRUPO [Nivel 1 - Depende de Asignatura]
     │
     ├─ atributos: id, nombre, anio, periodo, numero_estudiantes, asignatura
     ├─ ejemplo: "Diseño mecatrónico 2025B"
     │
     └──> ESTUDIANTE [Nivel 2 - Depende de Grupo]
          │
          ├─ atributos: id, codigo, nombre_completo, grupo
          └─ ejemplos de código: "1724226037", "1077227861", etc.
3.2. Rama de laboratorios (Laboratorio, Reserva, Docente)
text
Copiar código
LABORATORIO [Nivel 0 - Independiente]
│
├─ atributos: id, codigo, nombre, piso, facultad, capacidad_max
├─ ejemplos:
│  ├─ ID=1, "LAB-201", "Laboratorio de Mecatrónica FABLAB"
│  └─ ID=2, "LAB-402", "Laboratorio de Electrónica"
│
└──> RESERVA [Nivel 3 - Entidad Integradora]
    │
    ├─ atributos: id, fecha, hora_inicio, hora_fin, tipo,
    │             laboratorio, grupo, docente
    │
    └──> DOCENTE [Nivel 0 - Independiente, pero referenciado]
       ├─ atributos: id, codigo, nombre_completo, email, asignatura
       └─ ejemplos:
          ├─ "MARÍA CAMILA HERRERA PAREDES" (Diseño mecatrónico)
          └─ "JORGE ALBERTO MARTÍNEZ LOZANO" (Electrónica)
```          
### Reserva es la entidad que conecta ambas ramas, porque combina:

Un laboratorio físico.

Un grupo académico (que a su vez depende de una asignatura y tiene estudiantes).

Un docente responsable.

4. Análisis por entidad
4.1. Laboratorio (independiente)
Nivel de dependencia: 0
Depende de: nadie.

### Características:

Representa un espacio físico concreto (FABLAB o laboratorio de Electrónica).

Tiene código, nombre, piso, facultad y capacidad máxima de estudiantes.

Se usa como base para todas las reservas.

### Dependencias:

No depende de otras entidades.

Es referenciado por Reserva.

### Reglas de integridad:

Debe existir antes de registrar cualquier reserva.

Si se eliminara un laboratorio, habría que eliminar primero todas las reservas asociadas para que no queden referencias rotas.

### 4.2. Asignatura (independiente)
Nivel de dependencia: 0
Depende de: nadie.

Características:

Representa una materia que utiliza laboratorio.

Tiene un semestre asociado (por ejemplo, 6 o 7).

En este proyecto solo se modelan dos asignaturas:

Diseño mecatrónico.

Electrónica.

Dependencias:

No depende de otras entidades.

Es referenciada por Grupo.

Cada asignatura tiene exactamente un grupo en el periodo 2025B.

Reglas de integridad:

Debe existir antes de crear grupos.

Si se eliminara una asignatura, primero habría que eliminar sus grupos y, a su vez, estudiantes y reservas que dependan de esos grupos.

4.3. Grupo (depende de Asignatura)
Nivel de dependencia: 1
Depende de: Asignatura.

Dependencia:

Cada grupo tiene una referencia a una asignatura (grupo.asignatura).

En este proyecto se usa un grupo por asignatura y periodo.

Características:

Contiene información del periodo académico (año, periodo).

Mantiene el número de estudiantes asociados.

Sirve como enlace entre la parte académica y la parte de reservas: un grupo está asociado a una asignatura y aparece en las reservas de laboratorio.

Reglas de integridad:

No puede existir un grupo sin asignatura.

El número de estudiantes debe mantenerse dentro de los rangos establecidos (por ejemplo, entre 8 y 15).

Si se elimina un grupo, hay que eliminar antes sus estudiantes y sus reservas.

Ejemplo de validación:

Válido: Grupo con asignatura Diseño mecatrónico ya creada.

Inválido: Grupo referenciando una asignatura que no existe en el sistema.

4.4. Estudiante (depende de Grupo)
Nivel de dependencia: 2
Depende de: Grupo.

Dependencia:

Cada estudiante tiene un grupo asociado.

El grupo es el que determina a qué asignatura pertenece.

Características:

Cada estudiante tiene un código único (cadena numérica larga).

El código es la referencia principal para identificar al estudiante.

Se usa para listar quiénes están vinculados a un grupo que hace uso del laboratorio.

Reglas de integridad:

No puede existir un estudiante sin grupo.

El código del estudiante debe ser único en el sistema.

Si se elimina un grupo, hay que eliminar o reasignar primero sus estudiantes.

4.5. Docente (independiente)
Nivel de dependencia: 0
Depende de: nadie.

Características:

Representa el docente responsable de un grupo en el laboratorio.

Está asociado a una asignatura, lo que permite saber qué curso dirige.

Dependencias:

Es referenciado por Reserva.

En este proyecto se considera un docente por asignatura.

Reglas de integridad:

El docente debe existir antes de crear reservas donde aparezca como responsable.

En las reservas extracurriculares, el docente es obligatorio.

4.6. Reserva (entidad integradora)
Nivel de dependencia: 3 (la más profunda)
Depende de: Laboratorio, Grupo y Docente.

Dependencias:

Reserva.laboratorio → Laboratorio

Reserva.grupo → Grupo → Asignatura

Reserva.docente → Docente

Cadena completa:

text
Copiar código
Reserva
  → Laboratorio
  → Grupo → Asignatura
           → Estudiantes (a través del grupo)
  → Docente
Características:

Registra fecha, hora de inicio, hora de fin y tipo (REGULAR o EXTRACURRICULAR).

Conecta la parte física (laboratorio) con la parte académica (grupo y docente).

Se usa para construir el historial de uso del laboratorio y validar choques de horario.

Reglas de integridad:

No puede existir una reserva sin laboratorio, grupo y docente válidos.

Para un mismo laboratorio y una misma fecha, las franjas horarias no deben solaparse.

Reservas regulares:

Representan el horario normal de clase.

Reservas extracurriculares:

Deben tener un docente responsable.

Deben cumplir un rango de duración (por ejemplo, entre 1 y 3 horas).

No pueden chocar con una reserva regular ya existente.

5. Matriz de dependencias
Entidad	Nivel	Depende de	Es referenciada por	Tipo de relación
Laboratorio	0	-	Reserva	1:* (un laboratorio tiene muchas reservas)
Asignatura	0	-	Grupo	1:* (en este proyecto, se usa 1:1)
Docente	0	-	Reserva	1:*
Grupo	1	Asignatura	Estudiante, Reserva	N:1 hacia Asignatura, 1:* hacia hijos
Estudiante	2	Grupo	-	N:1
Reserva	3	Laboratorio, Grupo, Docente	-	N:1 con cada entidad padre

6. Reglas globales de integridad
6.1. Integridad referencial
Toda clave que referencia a otra entidad debe apuntar a un registro existente. Por ejemplo:

Si una reserva apunta al laboratorio LAB-201, ese laboratorio debe existir en la lista de laboratorios.

Si un estudiante pertenece al grupo de Diseño mecatrónico 2025B, ese grupo debe existir primero.

6.2. Orden de creación
Para evitar problemas, lo recomendable es seguir este orden:

Crear laboratorios, asignaturas y docentes.

Crear grupos asociados a las asignaturas.

Crear estudiantes asociados a los grupos.

Crear reservas que referencien laboratorio, grupo y docente.

6.3. Orden de eliminación
Para no dejar datos huérfanos, el orden de eliminación sería el inverso:

Eliminar reservas.

Eliminar estudiantes.

Eliminar grupos.

Eliminar laboratorios, asignaturas y docentes.

7. Ejemplos prácticos
7.1. Crear una reserva regular de clase
Pasos:

Verificar que el laboratorio (por ejemplo, LAB-201) está creado.

Verificar que el grupo “Diseño mecatrónico 2025B” existe.

Verificar que el docente asociado a Diseño mecatrónico existe.

Registrar la reserva con fecha, hora de inicio, hora de fin y tipo REGULAR.

Comprobar que no existe otra reserva en el mismo laboratorio, fecha y franja horaria que se solape.

7.2. Rechazar una reserva por choque de horario
Caso:

LAB-402 tiene una reserva regular el 11/07/2025 de 18:00 a 19:40.

Se intenta registrar otra reserva en LAB-402 el mismo día de 18:30 a 19:00.

Resultado esperado:

La segunda reserva se rechaza porque se solapa con la clase regular ya registrada en ese laboratorio y esa fecha.

7.3. Crear una reserva extracurricular válida
Pasos:

El laboratorio debe estar libre en la fecha y franja solicitada.

El grupo debe existir.

El docente debe existir (es obligatorio).

La duración debe respetar los límites establecidos para extracurriculares (por ejemplo, entre 60 y 180 minutos).

Registrar la reserva con tipo EXTRACURRICULAR.

8. Conclusión
Las dependencias entre entidades en este sistema permiten:

Mantener la integridad de los datos, evitando referencias rotas.

Garantizar un control básico sobre el uso de los laboratorios, validando solapamientos de horario.

Tener trazabilidad sobre qué grupo y qué docente usan cada laboratorio en una fecha y hora concretas.

Trabajar con una estructura simple, adecuada para un proyecto académico de POO en Python, sin sacrificar la coherencia del modelo.