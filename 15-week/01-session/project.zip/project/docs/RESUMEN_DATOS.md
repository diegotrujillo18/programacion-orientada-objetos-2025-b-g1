# Resumen del Sistema de Gestión de Laboratorios – Mecatrónica 2025B

## 1. Introducción

Este documento resume la estructura de datos utilizada en el sistema de gestión de laboratorios de Ingeniería Mecatrónica para el periodo 2025B. El enfoque del proyecto es intencionalmente limitado a dos laboratorios y dos asignaturas, con el objetivo de mantener un modelo sencillo, entendible y suficiente para demostrar los conceptos de programación orientada a objetos en Python.

---

## 2. Entidades y relaciones principales

Las entidades centrales del modelo son:

- Laboratorio
- Asignatura
- Grupo
- Docente
- Estudiante
- Reserva

La idea general es:

- Cada asignatura tiene un grupo en el periodo 2025B.
- Cada grupo tiene una lista de estudiantes.
- Cada laboratorio se reserva mediante objetos Reserva, que enlazan laboratorio, grupo y docente en una fecha y franja horaria concreta.

---

## 3. Laboratorios

En el sistema solo se modelan dos laboratorios, ambos pertenecientes a Ingeniería Mecatrónica.

| ID | Código  | Nombre                            | Piso | Facultad             | Capacidad máxima |
|----|---------|-----------------------------------|------|----------------------|------------------|
| 1  | LAB-201 | Laboratorio de Mecatrónica FABLAB | 2    | Ingeniería Mecatrónica | 15               |
| 2  | LAB-402 | Laboratorio de Electrónica        | 4    | Ingeniería Mecatrónica | 15               |

Características relevantes:

- Ambos laboratorios comparten la misma capacidad máxima (15 estudiantes).
- LAB-201 se asocia principalmente al trabajo de Diseño mecatrónico.
- LAB-402 se utiliza para actividades de Electrónica.

---

## 4. Asignaturas

Se modelan únicamente las dos asignaturas que efectivamente usan los laboratorios en este proyecto.

| ID | Nombre             | Semestre |
|----|--------------------|----------|
| 1  | Diseño mecatrónico | 7        |
| 2  | Electrónica        | 6        |

Puntos a tener en cuenta:

- Cada asignatura tiene exactamente un grupo en el periodo 2025B.
- Las asignaturas sirven como punto de referencia académico para las reservas (qué curso está usando el laboratorio).

---

## 5. Grupos

Cada asignatura tiene un grupo asociado en el periodo 2025B. El nombre del grupo incluye la asignatura y el periodo académico.

| ID | Nombre                        | Año  | Periodo | Número estimado de estudiantes | AsignaturaId |
|----|-------------------------------|------|---------|--------------------------------|--------------|
| 1  | Diseño mecatrónico 2025B      | 2025 | B       | 12                             | 1            |
| 2  | Electrónica 2025B             | 2025 | B       | 10                             | 2            |

Observaciones:

- El número de estudiantes se mantiene dentro del rango planteado en el diseño (entre 8 y 15).
- Los grupos son la base tanto para el listado de estudiantes como para la información que se muestra en el historial de reservas.

---

## 6. Docentes

Cada asignatura tiene un docente responsable, que aparece asociado en las reservas.

| ID | Código      | Nombre completo                          | Email                             | AsignaturaId |
|----|-------------|-------------------------------------------|-----------------------------------|--------------|
| 1  | 2000000001  | MARÍA CAMILA HERRERA PAREDES             | maria.herrera@universidad.edu     | 1            |
| 2  | 2000000002  | JORGE ALBERTO MARTÍNEZ LOZANO            | jorge.martinez@universidad.edu    | 2            |

Notas:

- Los códigos de docente empiezan por 2, para diferenciarlos de los códigos de estudiante.
- Cada docente se vincula a una única asignatura dentro de este proyecto.

---

## 7. Estudiantes

Los estudiantes se cargan como una lista por grupo. A continuación se incluye un ejemplo abreviado; en la implementación real se pueden completar más registros manteniendo el mismo esquema de códigos y nombres.

### 7.1. Estudiantes de Diseño mecatrónico 2025B (Grupo 1)

| ID | Código      | Nombre completo                              | GrupoId |
|----|------------|-----------------------------------------------|---------|
| 1  | 1724226037 | JUAN ESTUDIANTE PROYECTO                      | 1       |
| 2  | 1077227861 | ANDRES FELIPE AGUILAR AVENDAÑO                | 1       |
| 3  | 1077438160 | BRAYAN MAURICIO ARDILA ANDRADE                | 1       |
| 4  | 1077229322 | MARIA FERNANDA ARZAYUS DIAZ                   | 1       |

### 7.2. Estudiantes de Electrónica 2025B (Grupo 2)

| ID | Código      | Nombre completo                              | GrupoId |
|----|------------|-----------------------------------------------|---------|
| 5  | 1075598301 | SERGIO ANDRES DIAZ SUAREZ                     | 2       |
| 6  | 1002058016 | NICOLAS SANTIAGO FERNANDEZ VARGAS             | 2       |

Comentarios:

- El código de estudiante es la referencia principal para identificación.
- Cada estudiante está asociado a un único grupo en este contexto.

---

## 8. Reservas

La entidad Reserva es la que integra toda la información práctica de uso de laboratorios. Cada reserva enlaza:

- Laboratorio
- Grupo
- Docente
- Fecha
- Hora de inicio y fin
- Tipo de reserva (REGULAR o EXTRACURRICULAR)

A continuación se muestran algunas reservas de ejemplo acordes con los objetivos del proyecto.

| ID | Fecha       | Inicio | Fin   | Tipo            | LaboratorioId | GrupoId | DocenteId | Descripción                                         |
|----|------------|--------|-------|-----------------|---------------|---------|-----------|-----------------------------------------------------|
| 1  | 11/04/2025 | 18:00  | 19:40 | REGULAR         | 1             | 1       | 1         | Clase de Diseño mecatrónico 2025B en LAB-201        |
| 2  | 11/06/2025 | 18:00  | 19:40 | REGULAR         | 1             | 1       | 1         | Clase de Diseño mecatrónico 2025B en LAB-201        |
| 3  | 11/05/2025 | 18:00  | 19:40 | REGULAR         | 2             | 2       | 2         | Clase de Electrónica 2025B en LAB-402               |
| 4  | 11/07/2025 | 18:00  | 19:40 | REGULAR         | 2             | 2       | 2         | Clase de Electrónica 2025B en LAB-402               |
| 5  | 11/15/2025 | 08:00  | 09:40 | EXTRACURRICULAR | 1             | 1       | 1         | Práctica adicional de Diseño mecatrónico en FABLAB  |
| 6  | 11/20/2025 | 18:00  | 19:00 | EXTRACURRICULAR | 2             | 2       | 2         | Sesión extra de Electrónica en LAB-402              |

Aspectos importantes:

- Las reservas regulares representan clases en horario nocturno (18:00 a 19:40).
- Las reservas extracurriculares cumplen las restricciones mencionadas en el diseño: duración entre 1 y 3 horas, grupo con número de estudiantes adecuado y docente obligatorio.
- El sistema de consola valida solapamientos de horario dentro del mismo laboratorio y fecha.

---

## 9. Mapa de dependencias (resumen)

De forma resumida, las dependencias entre entidades se pueden ver así:

- Asignatura → Grupo (1 a 1 en este proyecto).
- Grupo → Estudiante (1 a muchos).
- Laboratorio → Reserva (1 a muchos).
- Grupo → Reserva (1 a muchos).
- Docente → Reserva (1 a muchos).

Es decir, una Reserva depende simultáneamente de:

- Un Laboratorio válido.
- Un Grupo válido.
- Un Docente válido.

---

## 10. Estadísticas generales de ejemplo

Basado en los datos iniciales planteados:

- Laboratorios: 2
- Asignaturas: 2
- Grupos: 2
- Docentes: 2
- Estudiantes cargados en el ejemplo: 6 (se pueden ampliar más en código)
- Reservas de ejemplo: 6  
  - 4 reservas regulares  
  - 2 reservas extracurriculares

---

## 11. Conclusión

El modelo de datos se mantiene intencionalmente reducido a dos laboratorios y dos asignaturas, lo que facilita:

- Entender con claridad las relaciones entre entidades.
- Explicar el diseño en términos de programación orientada a objetos.
- Demostrar validaciones básicas de negocio, como choque de horarios y reglas para reservas extracurriculares.
- Conectar de forma directa el backend en Python con una posible interfaz web sencilla, sin que el volumen de datos se vuelva inmanejable para la sustentación.

Este resumen sirve como guía de referencia rápida para entender qué datos maneja el sistema, cómo se relacionan y qué se está simulando exactamente durante el periodo 2025B.

