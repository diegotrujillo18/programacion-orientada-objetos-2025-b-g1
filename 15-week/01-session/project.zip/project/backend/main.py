"""Archivo principal del sistema de laboratorios (modo consola).

Este módulo ofrece un menú sencillo en consola para:
- Ver laboratorios por piso.
- Consultar historial de uso por laboratorio.
- Ver reservas de un laboratorio en una fecha específica.
- Registrar nuevas reservas (regulares o extracurriculares).
"""

from models import (
    Laboratorio,
    Asignatura,
    Grupo,
    Docente,
    Estudiante,
    Reserva,
    TIPO_REGULAR,
    TIPO_EXTRACURRICULAR,
    crear_datos_iniciales,
)


def minutos_entre(hora_inicio: str, hora_fin: str) -> int:
    """Calcula minutos entre dos horas 'HH:MM'."""
    h1, m1 = hora_inicio.split(":")
    h2, m2 = hora_fin.split(":")
    inicio = int(h1) * 60 + int(m1)
    fin = int(h2) * 60 + int(m2)
    return fin - inicio


def mostrar_laboratorios_por_piso(laboratorios):
    """Devuelve un laboratorio seleccionado por el usuario."""
    pisos_disponibles = sorted({lab.piso for lab in laboratorios})
    print("\n=== CONSULTA DE LABORATORIOS POR PISO ===")
    print("Pisos disponibles:")
    for piso in pisos_disponibles:
        print(f"- Piso {piso}")

    try:
        piso = int(input("Ingrese el número de piso (0 para volver): "))
    except ValueError:
        print("Entrada no válida. Regresando al menú principal.")
        return None

    if piso == 0:
        return None

    labs_piso = [lab for lab in laboratorios if lab.piso == piso]
    if not labs_piso:
        print("No hay laboratorios registrados para ese piso.")
        return None

    print(f"\nLaboratorios en el piso {piso}:")
    for idx, lab in enumerate(labs_piso, start=1):
        print(f"{idx}. {lab}")

    try:
        opcion = int(input("Seleccione un laboratorio (0 para cancelar): "))
    except ValueError:
        print("Entrada no válida.")
        return None

    if opcion == 0:
        return None

    if 1 <= opcion <= len(labs_piso):
        return labs_piso[opcion - 1]

    print("Opción fuera de rango.")
    return None


def mostrar_historial_laboratorio(laboratorio, reservas):
    """Muestra todas las reservas de un laboratorio."""
    print(f"\n=== HISTORIAL DE USO - {laboratorio.codigo} ===")
    reservas_lab = [
        r for r in reservas if r.laboratorio.id == laboratorio.id
    ]

    if not reservas_lab:
        print("No hay reservas registradas para este laboratorio.")
        return

    reservas_lab.sort(key=lambda r: (r.fecha, r.hora_inicio))

    for reserva in reservas_lab:
        print(f"\n{reserva}")
        print(f"  Asignatura: {reserva.grupo.asignatura.nombre}")
        print(f"  Docente: {reserva.docente.nombre_completo}")
        print("  Estudiantes:")
        if not reserva.grupo.estudiantes:
            print("    (No hay estudiantes cargados para este grupo aún)")
        else:
            for est in reserva.grupo.estudiantes:
                print(f"    {est.codigo} - {est.nombre_completo}")


def mostrar_reservas_por_fecha(laboratorio, reservas):
    """Muestra reservas de un laboratorio en una fecha específica."""
    print(f"\n=== CONSULTA POR FECHA - {laboratorio.codigo} ===")
    fecha = input("Ingrese la fecha (formato dd/mm/aaaa): ").strip()

    reservas_lab = [
        r
        for r in reservas
        if r.laboratorio.id == laboratorio.id and r.fecha == fecha
    ]

    if not reservas_lab:
        print("No hay reservas para esa fecha en este laboratorio.")
        return

    reservas_lab.sort(key=lambda r: r.hora_inicio)

    for reserva in reservas_lab:
        print(f"\n{reserva}")
        print(f"  Asignatura: {reserva.grupo.asignatura.nombre}")
        print(f"  Docente: {reserva.docente.nombre_completo}")
        print("  Estudiantes:")
        if not reserva.grupo.estudiantes:
            print("    (No hay estudiantes cargados para este grupo aún)")
        else:
            for est in reserva.grupo.estudiantes:
                print(f"    {est.codigo} - {est.nombre_completo}")


def obtener_docente_por_grupo(docentes, grupo):
    """Busca el docente asociado a la asignatura del grupo."""
    for docente in docentes:
        if docente.asignatura.id == grupo.asignatura.id:
            return docente
    return None


def registrar_reserva(laboratorio, datos):
    """Permite registrar una nueva reserva para un laboratorio."""
    reservas = datos["reservas"]
    grupos = datos["grupos"]
    docentes = datos["docentes"]

    print(f"\n=== REGISTRAR RESERVA EN {laboratorio.codigo} ===")

    fecha = input("Fecha (dd/mm/aaaa): ").strip()
    hora_inicio = input("Hora inicio (HH:MM): ").strip()
    hora_fin = input("Hora fin (HH:MM): ").strip()

    print("\nTipo de reserva:")
    print("1. REGULAR (clase normal)")
    print("2. EXTRACURRICULAR")
    tipo_op = input("Seleccione tipo [1/2]: ").strip()

    if tipo_op == "1":
        tipo = TIPO_REGULAR
    elif tipo_op == "2":
        tipo = TIPO_EXTRACURRICULAR
    else:
        print("Tipo no válido.")
        return

    print("\nGrupos disponibles:")
    for idx, grupo in enumerate(grupos, start=1):
        print(f"{idx}. {grupo.nombre} "
              f"(Semestre {grupo.asignatura.semestre})")

    try:
        op_grupo = int(input("Seleccione un grupo: "))
    except ValueError:
        print("Entrada no válida.")
        return

    if not (1 <= op_grupo <= len(grupos)):
        print("Opción de grupo fuera de rango.")
        return

    grupo_seleccionado = grupos[op_grupo - 1]
    docente = obtener_docente_por_grupo(docentes, grupo_seleccionado)

    if docente is None:
        print("No se encontró docente asociado a la asignatura del grupo.")
        return

    duracion = minutos_entre(hora_inicio, hora_fin)
    if duracion <= 0:
        print("La hora de fin debe ser mayor que la hora de inicio.")
        return

    if tipo == TIPO_EXTRACURRICULAR:
        if duracion < 60 or duracion > 180:
            print(
                "Reserva extracurricular inválida: "
                "duración mínima 1h, máxima 3h."
            )
            return
        if not (6 <= grupo_seleccionado.numero_estudiantes <= 15):
            print(
                "Reserva extracurricular inválida: el grupo debe tener "
                "entre 6 y 15 estudiantes."
            )
            return

    nuevo_id = len(reservas) + 1
    nueva_reserva = Reserva(
        nuevo_id,
        fecha,
        hora_inicio,
        hora_fin,
        tipo,
        laboratorio,
        grupo_seleccionado,
        docente,
    )

    for reserva in reservas:
        if nueva_reserva.se_solapa_con(reserva):
            print(
                "No se puede registrar la reserva: "
                "hay un choque de horario con otra reserva."
            )
            print(f"Reserva en conflicto: {reserva}")
            return

    reservas.append(nueva_reserva)
    print("\n[OK] Reserva creada correctamente:")
    print(nueva_reserva)


def menu_laboratorio(laboratorio, datos):
    """Submenú para un laboratorio específico."""
    reservas = datos["reservas"]

    while True:
        print(f"\n=== LABORATORIO SELECCIONADO: {laboratorio.codigo} ===")
        print("1. Ver historial completo de uso")
        print("2. Ver reservas por fecha")
        print("3. Registrar nueva reserva")
        print("0. Volver al menú principal")

        opcion = input("Seleccione una opción: ").strip()

        if opcion == "1":
            mostrar_historial_laboratorio(laboratorio, reservas)
        elif opcion == "2":
            mostrar_reservas_por_fecha(laboratorio, reservas)
        elif opcion == "3":
            registrar_reserva(laboratorio, datos)
        elif opcion == "0":
            break
        else:
            print("Opción no válida.")


def main():
    """Punto de entrada principal del programa."""
    datos = crear_datos_iniciales()
    laboratorios = datos["laboratorios"]

    while True:
        print("\n=== SISTEMA DE GESTIÓN DE LABORATORIOS (CONSOLA) ===")
        print("1. Ver laboratorios por piso")
        print("0. Salir")

        opcion = input("Seleccione una opción: ").strip()

        if opcion == "1":
            laboratorio = mostrar_laboratorios_por_piso(laboratorios)
            if laboratorio is not None:
                menu_laboratorio(laboratorio, datos)
        elif opcion == "0":
            print("Saliendo del sistema...")
            break
        else:
            print("Opción no válida, intente de nuevo.")


if __name__ == "__main__":
    main()
