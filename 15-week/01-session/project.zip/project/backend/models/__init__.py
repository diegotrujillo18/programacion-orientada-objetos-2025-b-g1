"""Modelos y datos iniciales del sistema de laboratorios."""

from .laboratorio import Laboratorio
from .asignatura import Asignatura
from .grupo import Grupo
from .docente import Docente
from .estudiante import Estudiante
from .reserva import Reserva, TIPO_REGULAR, TIPO_EXTRACURRICULAR


__all__ = [
    "Laboratorio",
    "Asignatura",
    "Grupo",
    "Docente",
    "Estudiante",
    "Reserva",
    "TIPO_REGULAR",
    "TIPO_EXTRACURRICULAR",
    "crear_datos_iniciales",
]


def crear_datos_iniciales():
    """Crea los datos base del semestre 2025B.

    Solo se usan dos laboratorios:
    - LAB-201: Diseño mecatrónico 2025B.
    - LAB-402: Electrónica 2025B.
    """

    # --- Laboratorios ---
    lab_fablab = Laboratorio(
        1,
        "LAB-201",
        "Laboratorio de Mecatrónica FABLAB",
        2,
        "Ingeniería Mecatrónica",
        15,
    )
    lab_electronica = Laboratorio(
        2,
        "LAB-402",
        "Laboratorio de Electrónica",
        4,
        "Ingeniería Mecatrónica",
        15,
    )
    laboratorios = [lab_fablab, lab_electronica]

    # --- Asignaturas ---
    asig_diseno = Asignatura(1, "Diseño mecatrónico", 7)
    asig_electronica = Asignatura(2, "Electrónica", 6)
    asignaturas = [asig_diseno, asig_electronica]

    # --- Grupos ---
    grupo_diseno = Grupo(
        1,
        "Diseño mecatrónico 2025B",
        2025,
        "B",
        asig_diseno,
    )
    grupo_electronica = Grupo(
        2,
        "Electrónica 2025B",
        2025,
        "B",
        asig_electronica,
    )
    grupos = [grupo_diseno, grupo_electronica]

    # --- Docentes (ids empiezan por 2, como acordamos) ---
    docente_diseno = Docente(
        2001,
        "ANDRES FELIPE AGUILAR AVENDAÑO",
        "andres.aguilar@universidad.edu",
        asig_diseno,
    )
    docente_electronica = Docente(
        2002,
        "SARA RODRIGUEZ ZAMBRANO",
        "sara.rodriguez@universidad.edu",
        asig_electronica,
    )
    docentes = [docente_diseno, docente_electronica]

    # --- Estudiantes ---
    estudiantes = []

    def crear_estudiante(id_base, codigo_str, nombre, grupo):
        est = Estudiante(id_base, codigo_str, nombre, grupo)
        grupo.agregar_estudiante(est)
        estudiantes.append(est)

    # Grupo Diseño mecatrónico 2025B (12 estudiantes)
    crear_estudiante(
        1001,
        "1724226037",
        "JUAN PABLO GONZALEZ TRUJILLO",
        grupo_diseno,
    )
    crear_estudiante(
        1002,
        "1724226038",
        "BRAYAN MAURICIO ARDILA ANDRADE",
        grupo_diseno,
    )
    crear_estudiante(
        1003,
        "1724226039",
        "MARIA FERNANDA ARZAYUS DIAZ",
        grupo_diseno,
    )
    crear_estudiante(
        1004,
        "1724226040",
        "ISABELLA BONILLA HERRERA",
        grupo_diseno,
    )
    crear_estudiante(
        1005,
        "1724226041",
        "JOHAN STEVEN CARDENAS GONZALEZ",
        grupo_diseno,
    )
    crear_estudiante(
        1006,
        "1724226042",
        "ERIC MAURICIO CASTAÑEDA MURCIA",
        grupo_diseno,
    )
    crear_estudiante(
        1007,
        "1724226043",
        "LINDA GREISSE CUENCA SANTANILLA",
        grupo_diseno,
    )
    crear_estudiante(
        1008,
        "1724226044",
        "SERGIO ANDRES DIAZ SUAREZ",
        grupo_diseno,
    )
    crear_estudiante(
        1009,
        "1724226045",
        "NICOLAS SANTIAGO FERNANDEZ VARGAS",
        grupo_diseno,
    )
    crear_estudiante(
        1010,
        "1724226046",
        "JUAN DAVID GUZMAN LAVAO",
        grupo_diseno,
    )
    crear_estudiante(
        1011,
        "1724226047",
        "SARA SOFIA MUÑOZ MORENO",
        grupo_diseno,
    )
    crear_estudiante(
        1012,
        "1724226048",
        "ANGIE LORENA MURCIA CULMA",
        grupo_diseno,
    )

    # Grupo Electrónica 2025B (10 estudiantes, los mismos excepto 2)
    crear_estudiante(
        2001,
        "1724226037",
        "JUAN PABLO GONZALEZ TRUJILLO",
        grupo_electronica,
    )
    crear_estudiante(
        2002,
        "1724226038",
        "BRAYAN MAURICIO ARDILA ANDRADE",
        grupo_electronica,
    )
    crear_estudiante(
        2003,
        "1724226039",
        "MARIA FERNANDA ARZAYUS DIAZ",
        grupo_electronica,
    )
    crear_estudiante(
        2004,
        "1724226040",
        "ISABELLA BONILLA HERRERA",
        grupo_electronica,
    )
    crear_estudiante(
        2005,
        "1724226041",
        "JOHAN STEVEN CARDENAS GONZALEZ",
        grupo_electronica,
    )
    crear_estudiante(
        2006,
        "1724226042",
        "ERIC MAURICIO CASTAÑEDA MURCIA",
        grupo_electronica,
    )
    crear_estudiante(
        2007,
        "1724226043",
        "LINDA GREISSE CUENCA SANTANILLA",
        grupo_electronica,
    )
    crear_estudiante(
        2008,
        "1724226044",
        "SERGIO ANDRES DIAZ SUAREZ",
        grupo_electronica,
    )
    crear_estudiante(
        2009,
        "1724226045",
        "NICOLAS SANTIAGO FERNANDEZ VARGAS",
        grupo_electronica,
    )
    crear_estudiante(
        2010,
        "1724226046",
        "JUAN DAVID GUZMAN LAVAO",
        grupo_electronica,
    )

    # --- Reservas iniciales ---
    reservas = []

    def crear_reserva(id_, fecha, h_ini, h_fin, tipo, lab, grupo, docente):
        reserva = Reserva(id_, fecha, h_ini, h_fin, tipo, lab, grupo, docente)
        reservas.append(reserva)

    # Diseño mecatrónico en FABLAB (LAB-201)
    crear_reserva(
        1,
        "10/11/2025",
        "18:00",
        "19:40",
        TIPO_REGULAR,
        lab_fablab,
        grupo_diseno,
        docente_diseno,
    )
    crear_reserva(
        2,
        "12/11/2025",
        "18:00",
        "19:40",
        TIPO_REGULAR,
        lab_fablab,
        grupo_diseno,
        docente_diseno,
    )

    # Electrónica en LAB-402
    crear_reserva(
        3,
        "11/11/2025",
        "18:00",
        "19:40",
        TIPO_REGULAR,
        lab_electronica,
        grupo_electronica,
        docente_electronica,
    )
    crear_reserva(
        4,
        "13/11/2025",
        "18:00",
        "19:40",
        TIPO_REGULAR,
        lab_electronica,
        grupo_electronica,
        docente_electronica,
    )

    # Extracurriculares de ejemplo
    crear_reserva(
        5,
        "15/11/2025",
        "08:00",
        "09:40",
        TIPO_EXTRACURRICULAR,
        lab_fablab,
        grupo_diseno,
        docente_diseno,
    )
    crear_reserva(
        6,
        "20/11/2025",
        "08:00",
        "09:40",
        TIPO_EXTRACURRICULAR,
        lab_electronica,
        grupo_electronica,
        docente_electronica,
    )

    return {
        "laboratorios": laboratorios,
        "asignaturas": asignaturas,
        "grupos": grupos,
        "docentes": docentes,
        "estudiantes": estudiantes,
        "reservas": reservas,
    }
