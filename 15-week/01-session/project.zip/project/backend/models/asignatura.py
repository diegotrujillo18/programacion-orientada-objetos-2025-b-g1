class Asignatura:
    """Representa una asignatura que usa los laboratorios."""

    def __init__(self, id_, nombre, semestre):
        self.id = id_
        self.nombre = nombre
        self.semestre = semestre

    def __str__(self) -> str:
        return f"{self.nombre} (Semestre {self.semestre})"
