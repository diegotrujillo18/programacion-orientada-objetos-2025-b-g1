from .persona import Persona


class Estudiante(Persona):
    """Representa un estudiante con código institucional."""

    def __init__(self, id_, codigo, nombre_completo, grupo=None):
        super().__init__(id_, nombre_completo)
        self.codigo = codigo
        self.grupo = grupo

    def __str__(self) -> str:
        grupo_nombre = self.grupo.nombre if self.grupo else "Sin grupo"
        return f"{self.codigo} - {self.nombre_completo} ({grupo_nombre})"
