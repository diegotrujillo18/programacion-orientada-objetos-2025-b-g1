from .persona import Persona


class Docente(Persona):
    """Representa un docente responsable de un grupo o reserva."""

    def __init__(self, id_, nombre_completo, email, asignatura=None):
        super().__init__(id_, nombre_completo)
        self.email = email
        # No tipamos fuerte para evitar ciclos de import
        self.asignatura = asignatura

    def __str__(self) -> str:
        return f"{self.nombre_completo} <{self.email}>"
