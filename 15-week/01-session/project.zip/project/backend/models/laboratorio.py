class Laboratorio:
    """Representa un laboratorio físico."""

    def __init__(self, id_, codigo, nombre, piso, facultad, capacidad_max):
        self.id = id_
        self.codigo = codigo
        self.nombre = nombre
        self.piso = piso
        self.facultad = facultad
        self.capacidad_max = capacidad_max

    def __str__(self) -> str:
        return (
            f"{self.codigo} - {self.nombre} "
            f"(Piso {self.piso}, Capacidad {self.capacidad_max})"
        )
