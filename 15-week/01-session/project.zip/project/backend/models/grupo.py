class Grupo:
    """Agrupa estudiantes para una asignatura en un periodo."""

    def __init__(self, id_, nombre, anio, periodo, asignatura):
        self.id = id_
        self.nombre = nombre
        self.anio = anio
        self.periodo = periodo
        self.asignatura = asignatura
        self.estudiantes = []  # lista de Estudiante

    @property
    def numero_estudiantes(self) -> int:
        return len(self.estudiantes)

    def agregar_estudiante(self, estudiante) -> None:
        """Añade un estudiante al grupo."""
        self.estudiantes.append(estudiante)

    def __str__(self) -> str:
        return (
            f"{self.nombre} - {self.anio}{self.periodo} "
            f"({self.numero_estudiantes} estudiantes)"
        )
