class Persona:
    """Clase base para personas (docentes y estudiantes)."""

    def __init__(self, id_, nombre_completo):
        self.id = id_
        self.nombre_completo = nombre_completo

    def __str__(self) -> str:
        return self.nombre_completo
