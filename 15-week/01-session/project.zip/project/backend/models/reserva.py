TIPO_REGULAR = "REGULAR"
TIPO_EXTRACURRICULAR = "EXTRACURRICULAR"


class Reserva:
    """Reserva de un laboratorio para un grupo y docente."""

    def __init__(
        self,
        id_,
        fecha,
        hora_inicio,
        hora_fin,
        tipo,
        laboratorio,
        grupo,
        docente,
    ):
        self.id = id_
        self.fecha = fecha              # "dd/mm/aaaa"
        self.hora_inicio = hora_inicio  # "HH:MM"
        self.hora_fin = hora_fin        # "HH:MM"
        self.tipo = tipo                # REGULAR o EXTRACURRICULAR
        self.laboratorio = laboratorio
        self.grupo = grupo
        self.docente = docente

    def _a_minutos(self, hora: str) -> int:
        """Convierte 'HH:MM' a minutos desde las 00:00."""
        h, m = hora.split(":")
        return int(h) * 60 + int(m)

    def se_solapa_con(self, otra_reserva) -> bool:
        """Indica si esta reserva se solapa con otra en mismo laboratorio."""
        if self.laboratorio.id != otra_reserva.laboratorio.id:
            return False
        if self.fecha != otra_reserva.fecha:
            return False

        inicio1 = self._a_minutos(self.hora_inicio)
        fin1 = self._a_minutos(self.hora_fin)
        inicio2 = otra_reserva._a_minutos(otra_reserva.hora_inicio)
        fin2 = otra_reserva._a_minutos(otra_reserva.hora_fin)

        return inicio1 < fin2 and fin1 > inicio2

    def __str__(self) -> str:
        return (
            f"Reserva #{self.id} - {self.fecha} "
            f"{self.hora_inicio}-{self.hora_fin} ({self.tipo}) | "
            f"{self.laboratorio.codigo} | {self.grupo.nombre} | "
            f"{self.docente.nombre_completo}"
        )
